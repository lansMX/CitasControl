<?php 

	include '../js/adminBase.php';

 ?>