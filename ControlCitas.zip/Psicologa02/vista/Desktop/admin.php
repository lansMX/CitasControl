<?php 

	include '../adminBase.php';

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Administracion</title>	
</head>
<body>
	<h1></h1>

	<script type="text/javascript" src="../js/admin.js"></script>
</body>
</html>