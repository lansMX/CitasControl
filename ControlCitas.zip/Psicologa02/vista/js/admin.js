function menu(attr){
	$.each(attr, function(i, val){
		$("#men_prin>li:nth-child("+(i+1)+")").after("<li><a href=''>"+val+"</a></li>");
	});
}

menu(["Expediente", "Registro", "Ingresos"]);

$(document).ready(function(){
	$("#men_prin>li").click(function(e){		
		$("#men_prin>li").children().removeClass("active");
		$(this).children().addClass("active");
	});
});