<?php 

	/**
	* 
	*/
	class Contactos implements operacionesCRUD
	{
		function registraBD()
		{
			
		}

		function consultaBD(){}

		function actualizaBD(){}

		function eliminaBD(){}
	}

	
	if (isset()) {
		
	}


 ?>