<?php 

	require_once(__DIR__.'\db\conexion.php');
	require_once('mVfor.php');
 
 /**
 * 
 */
 class Modelo
 { 	
	const NO_PERMITIDO = "# $ % ^ & * ( ) + = - [ ] ' ; , . / { } | : < > ? ~ \"";

	/**
	* CONTACTOS
	*/
	function reqCotactos(){
		
	}

	/**
	* REGISTRO
	*/
	function reqRegistro(){

	}

	/**
	* Inicio de sesion
	*/
	function inicioSesi($cadena){

		if($this->validacionQuery(join($cadena)) === "validado"){
			echo "entra<br>";
			$bd = new conexion();
			var_dump($cadena);
			$test = $bd->consulta($cadena, "pacientes");
			return $test;
		}		
		else{
			echo "No";
		}
	}

	function clasificador($string){
		Redirect('http://example.com/', false);
	} 	

 	/**
 	* Validacion
 	*/
 	function validacionQuery($string){
 		$perms = explode(" ", $this->getPerm());
 		foreach ($perms as $char) {
 			if (strpos($string, $char)) {
				return "Contraseña incorrecta";
				exit();			
			}	
 		}		
		return "validado";
 	}

 	public static function getPerm() 
	{ 
		return self::NO_PERMITIDO; 
	} 

 	function Redirect($url, $permanent = false)
	{
		header("Location: " . $url);
		exit();
	}

	function getField($campo, $criterio, $loc){
		header("Location: $loc?op=fd&cm=$campo&cr=$criterio");
	}

 }


	if(isset($_GET['us']) && isset($_GET['ps'])){
		$nom = $_GET['us'];
		$con = $_GET['ps'];
		if (mVfor($nom) && mVfor($con)) {
			$md = new Modelo();
			if(($resp = $md->inicioSesi(array(0=>$nom, 1=>$con))) !== false) {
				$md->getField("role", $resp, "Entidades/pacientes.php");
			}
		}
		else {
			throw new Exception("Verifique sus datos", 1);
			
			header("index.php");
		}
	}

	if (isset($_GET['rl'])) {
		echo "regreso";
		if ($_GET['rl'] == "suprU") {
			header('Location: ../vista/Desktop/admin.php');	
		}else{
			header('Location: ../vista/Desktop/paciente.php');
		}
	}	

 ?>	