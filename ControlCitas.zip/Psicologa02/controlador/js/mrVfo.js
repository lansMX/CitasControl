function mrVfo(campo) {
	
}

